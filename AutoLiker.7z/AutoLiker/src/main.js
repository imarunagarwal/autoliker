async function shouldApplyChangesOnPage(currentUrl) {
  let UrlRegex = new RegExp(`https://www.linkedin.com/feed(.*)`, 'i');
  return currentUrl.href.match(UrlRegex) == null ? false : true;
}

function likePosts(arr) {
  arr.forEach(el => {
    if (!el.classList.contains('react-button--active')) {
      el.click();
      el.classList.remove('social-actions-button', 'react-button__trigger');
    }
  });
  return arr[arr.length - 1];
}

async function mainInit() {
  let currentUrl = new URL(window.location);
  let shouldWork = await shouldApplyChangesOnPage(currentUrl);
  if (shouldWork) {
    setInterval(() => {
      // Click on like buttons
      const lastEl = likePosts(
        document.querySelectorAll('.feed-shared-social-actions .social-actions-button.react-button__trigger')
      );
      lastEl?.scrollIntoView({ block: 'start', inline: 'nearest', behavior: 'smooth' });
    }, 2000);
    // Scroll the page after 2 sec
  }
}

// To make sure that all the async requests are complete and buttons can be generated now
window.onload = () => {
  mainInit();
};
