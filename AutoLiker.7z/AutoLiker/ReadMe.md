# Autoliker
Browser extension that auto likes Linkedin Posts

#### Chrome

Installing locally:
* Go to Chrome Settings > Extensions > Toggle Developer Mode On > Load Unpacked > Browse to git directory > Select `\src` as your folder
![](assets/chrome-load-extension.PNG)

Any updates that you make will require a "Reload" in the Extensions screen (the refresh button).

## About ME
Github: [imarunagarwal](https://www.github.com/imarunagarwal)

## Future Scope: 
It can be modified as per requirement and can be integrated with other social meida like Instagram, facebook etc.  
